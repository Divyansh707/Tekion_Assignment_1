package com.example.handlingformsubmission;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class launchCricketController {

    @GetMapping("/launchCricket")
    public String launchCricketForm(Model model) {
        model.addAttribute("launchCricket", new launchCricket());
        return "launchCricket";
    }

    @PostMapping("/launchCricket")
    public String launchCricketSubmit(@ModelAttribute launchCricket launchCricket) {
        return "result";
    }

}